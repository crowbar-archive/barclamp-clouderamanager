#!/usr/bin/ruby

puts "Setting up the JDBC connector"
`tar -xvf mysql-connector-java-5.1.27.tar.gz`
`mv mysql-connector*.jar /usr/lib/sqoop/lib`

 puts "Setting up mysql server on this node."
 if `yum list installed | grep "mysql-server"` != ""
     puts "mysql-server is already installed."
 else
    `yum install -y mysql-server`
 end
 `chkconfig mysqld on`
 `service mysqld start`

