#!/usr/bin/ruby
#Running teragen/terasort jobs


$exit = {}

def run_tera()
    puts "Creating new /user/hdfs directory and change the ownership to hdfs"
    `hdfs dfs -mkdir  hdfs:///user/hdfs`
    `hdfs dfs -chown hdfs:hdfs hdfs:///user/hdfs`

    puts "Removing any earlier directories for teragen/terasort"
    `hdfs dfs -rm -r -skipTrash hdfs:///user/hdfs/teragen hdfs:///user/hdfs/terasort`

    #Teragen job
    `hadoop jar /usr/lib/hadoop-0.20-mapreduce/hadoop-examples-2.0.0-mr1-cdh4.4.0.jar teragen 10000 hdfs:///user/hdfs/teragen`
    `hdfs dfs -test -e hdfs:///user/hdfs/teragen/_SUCCESS`

    $exit[:teragen]=$?.exitstatus

    #Terasort job
    `hadoop jar /usr/lib/hadoop-0.20-mapreduce/hadoop-examples-2.0.0-mr1-cdh4.4.0.jar terasort hdfs:///user/hdfs/teragen hdfs:///user/hdfs/terasort`
    `hdfs dfs -test -e hdfs:///user/hdfs/terasort/_SUCCESS`
    $exit[:terasort]=$?.exitstatus
end


def run_pig()
    puts "Removing any previous pig output files"
    `hdfs dfs -rm -r -skipTrash hdfs:///user/hdfs/pig_test_output hdfs:///user/hdfs/passwd`

    puts "Copying the /etc/passwd file to hdfs home directory and copying it to from the local file system to hdfs"
    `cp /etc/passwd .`
    `hdfs dfs -put ./passwd hdfs:///user/hdfs/passwd`

    puts "Writing to a pig script"
    pig_script = File.open("pig_script","w")
    pig_script.puts(<<-EOF)
        A = load 'passwd' using PigStorage (':') ;
        B = foreach A generate $0 as id;
        store B into 'pig_test_output';
    EOF
    pig_script.close()

    puts "Executing pig_script"
    `pig -x mapreduce pig_script`

    `hdfs dfs -test -e hdfs:///user/hdfs/pig_test_output/_SUCCESS`

    $exit[:pig]=$?.exitstatus
end

#run hive
def run_hive()
##This script creates two tables, two_columns and single_column.
##Then it takes the first column from the table two_columns and puts that data as a first_column in the single_column table.
##The script tests if the output of the single_column table has more than one row
##You could also check if there's output in the files two_columns and single_column under /user/hive/warehouse directory.
#

    puts "Removing any previous hive output files"
    `hdfs dfs -rm -r -skipTrash hdfs:///user/hive/warehouse/two_columns hdfs:///user/hive/warehouse/single_column `
    `rm -rf two_columns.csv hive_script`
    puts "Writing test data for the hive script execution"


    two_columns = File.open("two_columns.csv","w")
    two_columns.puts(<<-EOF)
	1,test1
        2,test2
        3,test3
        4,test4
        5,test5
        6,test6
    EOF
    two_columns.close()

    puts "Writing instructions into a hive script"
    hive_script = File.open("hive_script","w")
    hive_script.puts(<<-EOF)
    drop table if exists two_columns;
    drop table if exists single_column;
    create external table two_columns(first_column int, second_column string) ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n';
    create external table single_column(first_column int);
    load data local inpath 'two_columns.csv' into table two_columns;
    from two_columns insert overwrite table single_column select first_column;
    EOF
    hive_script.close()

    puts "Executing hive_script"
    `hive -f hive_script`

    `hdfs dfs -cat hdfs:///user/hive/warehouse/single_column/* | wc -l > 0`
    $exit[:hive]=$?.exitstatus
end

#run sqoop
def run_sqoop()
#Cleanup
    
    `hdfs dfs -rm -r -skipTrash hdfs:///user/hdfs/users`
    `rm mysql_script.sql`


    puts "Creating necessary data in mysql database"
    mysql_script = File.open("mysql_script.sql","w")
    mysql_script.puts(<<-EOF)
    use test;
    drop table if exists users;
    create table users(name varchar(20) primary key, age int);
    insert into users (name,age) values ('abc',10);
    insert into users (name,age) values ('def',20);
    insert into users (name,age) values ('ghi',30);
    insert into users (name,age) values ('jkl',40);
    EOF
    mysql_script.close()

    `mysql test < mysql_script.sql`

    puts "Writing instructions into a sqoop script"
    sqoop_script = File.open("sqoop_script","w")
    sqoop_script.puts(<<-EOF)
    create database if not exists test;
    use test;
    create table users(foo int, bar text);
    insert into users (foo,bar) values (1,'something'),(2,'test'),(3,'data');
    EOF
    sqoop_script.close()

    `sqoop eval --connect jdbc:mysql://localhost/test --query "select * from test.users"`

    $exit[:sqoop]=$?.exitstatus
end


#run impala

def run_impala()

    puts "Running cleanup. Deleting all the hdfs directories and dropping all relevant tables on impala"
    `hdfs dfs -rm -r -skipTrash /user/impala/`
    `impala-shell -q "drop table if exists default.tab1; drop table if exists default.tab2; drop table if exists tpcds.customer; drop table if exists tpcds.customer_address; drop database if exists tpcds;"`

    `hdfs dfs -mkdir -p /user/impala`
    `hdfs dfs -chown impala:impala /user/impala`

    `hdfs dfs -mkdir -p /user/impala/sample_data/tab1 /user/impala/sample_data/tab2 /user/impala/sample_data/tab3`


    puts "Writing data into tab1.csv"
    tab1 = File.open("tab1.csv","w")
    tab1.puts(<<-EOF)
    1,true,123.123,2012-10-24 08:55:00
    2,false,1243.5,2012-10-25 13:40:00
    3,false,24453.325,2008-08-22 09:33:21.123
    4,false,243423.325,2007-05-12 22:32:21.33454
    5,true,243.325,1953-04-22 09:11:33
    EOF
    tab1.close()


    puts "Writing data into tab2.csv"
    tab2 = File.open("tab2.csv","w")
    tab2.puts(<<-EOF)
    1,true,12789.123
    2,false,1243.5
    3,false,24453.325
    4,false,2423.3254
    5,true,243.325
    60,false,243565423.325
    70,true,243.325
    80,false,243423.325
    90,true,243.325
    EOF
    tab2.close()

    `hdfs dfs -put tab1.csv /user/impala/sample_data/tab1`
    `hdfs dfs -put tab2.csv /user/impala/sample_data/tab2`

    `impala-shell -q "DROP TABLE IF EXISTS default.tab1;
    -- The EXTERNAL clause means the data is located outside the central location for Impala data files
    -- and is preserved when the associated Impala table is dropped. We expect the data to already
    -- exist in the directory specified by the LOCATION clause.
    CREATE EXTERNAL TABLE default.tab1
	(
	id INT,
	col_1 BOOLEAN,
	col_2 DOUBLE,
	col_3 TIMESTAMP
	)
	ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
	LOCATION '/user/impala/sample_data/tab1';
	
	DROP TABLE IF EXISTS default.tab2;
	-- TAB1 is an external table, similar to TAB1.
	CREATE EXTERNAL TABLE default.tab2
	(
	id INT,
	col_1 BOOLEAN,
	col_2 DOUBLE
	)
	ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
	LOCATION '/user/impala/sample_data/tab2';
	-- Create a new customer_setup.sql with the following content.
	--
	-- store_sales fact table and surrounding dimension tables only
	--
	create database tpcds;
	use tpcds;
	
	drop table if exists customer;
	create external table customer
	(
	c_customer_sk int,c_customer_id string,c_current_cdemo_sk int,c_current_hdemo_sk int,
	c_current_addr_sk int,c_first_shipto_date_sk int,c_first_sales_date_sk int,c_salutation string,
	c_first_name string,c_last_name string,c_preferred_cust_flag string,c_birth_day int,c_birth_month int,
	c_birth_year int,c_birth_country string,c_login string,c_email_address string,c_last_review_date string
	)
	row format delimited fields terminated by '|'
	location '/user/hive/warehouse/tpcds/customer';
	
	drop table if exists customer_address;
	create external table customer_address
	(
	ca_address_sk int,ca_address_id string,ca_street_number string,ca_street_name string,ca_street_type string,
	ca_suite_number string,ca_city string,ca_county string,ca_state string,ca_zip string,ca_country string,
	ca_gmt_offset float,ca_location_type string
	)
	row format delimited fields terminated by '|'
	location '/user/hive/warehouse/tpcds/customer_address';"`

    $exit[:impala]=$?.exitstatus
end



run_tera()
run_pig()
run_sqoop()
run_hive()
run_impala()

puts "\n"

if $exit[:teragen] == 0
    puts "Teragen test passed."
else
    puts "Teragen test failed!"
end

if $exit[:terasort] == 0
    puts "Terasort test passed."
else
    puts "Terasort test failed!"
end

if $exit[:pig] == 0
    puts "Pig test passed."
else
    puts "Pig test failed!"
end

if $exit[:sqoop] == 0
    puts "Sqoop test passed."
else
    puts "Sqoop test failed!"
end

if $exit[:hive] == 0
    puts "Hive test passed."
else
    puts "Hive test failed!"
end

if $exit[:impala] == 0
    puts "Impala test passed."
else
    puts "Impala test failed!"
end

