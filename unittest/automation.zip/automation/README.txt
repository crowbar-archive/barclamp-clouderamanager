automation_run script removes the pain of connecting to nodes and trying
to run Hadoop related jobs manually. It however doesn't eliminate the need
to completely login to a node yet.

The following assumptions are made for this script to run successfully.
It is assumed that the user will follow these instructions exactly before running
the script.

mysql_server_install.rb should be run first and then automation_run.rb should 
be executed for the automation tests to run successfully.

The scripts can be run as ./mysql_server_install.rb and ./automation_run.rb

-------------------------------
mysql_server_install.rb script:
-------------------------------
- The mysql_server_install.rb needs to be run as user: root.
- mysql-connector-java*.jar file should be in the same folder as the
  mysql_server_install.rb file for this script to run successfully.
- You can uninstall mysql-server from the node if that's what's needed by running.
  "yum remove mysql-server"

-------------------------
automation_run.rb script:
-------------------------
- Before running the automation_run.rb script make sure that the following
  services are already added in the Cloudera Manager UI.
    -HDFS
    -Map Reduce
    -Hive
    -Impala

Note: The Pig and Sqoop services don't need to be installed on Cloudera Manager
for those respective services to run.

Pig:
It is installed in the backend through CDH. The installation of the Pig barclamp
is not necessary for the pig test to run. However, installing the Pig barclamp
will not affect running the Pig test either.

Sqoop:
It is also not necessary to install the Sqoop service before running the Sqoop test.
The Sqoop service on Cloudera Manager is the new version of Sqoop 2.0. The basic version
of Sqoop comes with the installation of CDH also. However, installing the Sqoop service
on Cloudera Manager should not affect the running of the sqoop test either.

- It is assumed that the automation_run.rb will be run on a Data node only.
- It is assumed that there is an impala daemon running on the data node the script is
  run on.
- The automation_run.rb file should be run as user: hdfs.


The following tests will be run as a part of automation_run.

Teragen:
Teragen test creates 10,000 lines of random text as a part of the teragen job.

The output of this job can be verified as follows:
hdfs dfs -ls hdfs:///user/hdfs/teragen

Terasort:
Terasort takes the output from hdfs:///user/hdfs/teragen directory and sorts the data.

The output of this job can be verified as follows:
hdfs dfs -ls hdfs:///user/hdfs/terasort

Pig:
The /etc/passwd which exists by default on all redhat machines is used as a part of the pig test.

It copies the /etc/passwd file to the directory where the script is executing from currently.
Puts this file in hdfs:///user/hdfs/passwd file.
Then run's a pig script which parses the passwd file with a delimiter ':'
The output is written to hdfs:///user/hdfs/pig_test_output

The test looks for a _SUCCESS file in this directory to determine if the test passed successfully.

Hive:
The hive test creates two tables in the 'default' database called 'two_columns' and 'single_column'.
The test then takes the first column from the table 'two_columns' and puts that data as a
'first_column' in the 'single_column' table.
To determine if the test was successful the output of the single_column table is checked to see if it 
has more than one row
The use can also check if there's output in the files two_columns and single_column under the
/user/hive/warehouse directory.

Sqoop:
Before running the Sqoop test, we create a table called 'users' in the 'test' database
in the mysql-server.
We insert some data into this table.

Then we run a sqoop command to select data from this users table and check to see if the script was
successful.

Impala:
We create two files called tab1.csv and tab2.csv in the local directory.
We then put them in hdfs under hdfs:///user/impala/sample_data folder.
We import this data into Impala tables called tab1 and tab2.
Since these are external tables, no table metadata is created on impala.
We also create two tables called 'customer' and 'customer_address'.
This test is to mainly check if were able to create all these tables successfully.


At the end of all these tests,
a report is generated stating which of the tests were successful.
In an ideal world, all of these tests should pass successfully ;)
